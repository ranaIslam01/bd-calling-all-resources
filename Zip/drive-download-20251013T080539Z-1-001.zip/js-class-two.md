# JavaScript Class 2 – Operators, Conditions & Loops



---

In the previous class, we learned about **variables (`var`, `let`, `const`)** and **some data types**.  
In this class, we’ll learn how to **use those values with logic** using **operators, conditional statements, and loops**.  

---

## Recap: JavaScript Data Types

In JavaScript, there are two main categories of data types:

### 1. **Primitive Data Types**
These are immutable and store a single value:
- **String** → `"Hello"`, `'World'`
- **Number** → `42`, `3.14`
- **Boolean** → `true`, `false`
- **Undefined** → a variable declared but not assigned a value
- **Null** → represents intentional "nothing"
- **Symbol** → unique and immutable value (often for object keys)
- **BigInt** → very large integers beyond Number limit (e.g., `9007199254740991n`)

### 2. **Non-Primitive (Reference) Data Types**
These can store collections or more complex data:
- **Object** → `{ name: "john doe", age: 45 }`
- **Array** → `[1, 2, 3, 4]`
- **Function** → `function greet() { return "Hello"; }`


## 🔹 1. Operators in JavaScript

Operators are symbols that let us perform actions on values.  

### ➤ (a) Arithmetic Operators  
Used for basic math operations.  

```js
let a = 10, b = 3;

console.log(a + b); // 13 (addition)
console.log(a - b); // 7 (subtraction)
console.log(a * b); // 30 (multiplication)
console.log(a / b); // 3.333... (division)
console.log(a % b); // 1 (remainder)
```

👉 Example: Check if a number is even or odd using `%`.  

---

### ➤ (b) Assignment Operators  
Used to assign or update values in variables.  

```js
let x = 5;
x = 10;    // assign 10
x += 2;    // x = x + 2 → 12
x -= 4;    // x = x - 4 → 8
```

👉 Example: Updating scores, money, or counters.  

---

### ➤ (c) Comparison Operators  
Used to compare two values.  
They return either `true` or `false`.  

```js
console.log(5 == "5");   // true (only checks value)
console.log(5 === "5");  // false (checks value + type)
console.log(10 > 7);     // true
console.log(8 <= 5);     // false
```

👉 Example: Check if someone is old enough to drive.  

---

### ➤ (d) Logical Operators  
Used to combine multiple conditions.  

```js
let age = 20;

console.log(age > 18 && age < 30);  // true (AND: both must be true)
console.log(age > 18 || age > 65);  // true (OR: at least one is true)
console.log(!(age > 18));           // false (NOT: reverses result)
```

👉 Example: Check if age is between 18 and 30.  

---

## 🔹 2. Conditional Statements  

Conditional statements help programs **make decisions**.  
Like: *“If it rains, take an umbrella, otherwise don’t.”*  

---

### ➤ (a) if / else if / else  

```js
let marks = 75;

if (marks >= 80) {
  console.log("Grade A");
} else if (marks >= 60) {
  console.log("Grade B");
} else {
  console.log("Grade C");
}
```

👉 Example: Show different messages for different marks.  

---

### ➤ (b) switch Statement  

Used when we have **many choices**.  

```js
let color = "red";

switch (color) {
  case "red":
    console.log("Stop");
    break;
  case "green":
    console.log("Go");
    break;
  case "yellow":
    console.log("Wait");
    break;
  default:
    console.log("Unknown color");
}
```

---

## 🔹 3. Loops  

Loops allow us to **repeat code automatically** instead of writing it many times.  

---

### ➤ (a) for loop  

Best when we know **how many times** to repeat.  

```js
for (let i = 1; i <= 5; i++) {
  console.log("Number:", i);
}
// Output: 1 2 3 4 5
```

---

### ➤ (b) while loop  

Best when we **don’t know the number of repetitions** beforehand.  

```js
let i = 1;
while (i <= 5) {
  console.log("Number:", i);
  i++;
}
```

👉 Example: Keep asking for a password until it is correct.  

---

### ➤ (c) do...while loop  

This loop runs **at least once**, even if the condition is false,  
because the check happens *after* the code runs.  

```js
let i = 1;

do {
  console.log("Number:", i);
  i++;
} while (i <= 5);
```

👉 Example: Always show a menu at least once before checking if the user wants to exit.  

---

## 🔹 4. Practice Exercises  

Here are some mini challenges to try:  

---

### ✅ 1. Even or Odd Checker  

```js
let num = 7;
if (num % 2 === 0) {
  console.log("Even");
} else {
  console.log("Odd");
}
```

---

###  2. Voting Eligibility  

```js
let age = 16;
if (age >= 18) {
  console.log("You can vote!");
} else {
  console.log("You cannot vote yet.");
}
```

---

###  3. Multiplication Table  

```js
let n = 5;
for (let i = 1; i <= 10; i++) {
  console.log(`${n} x ${i} = ${n * i}`);
}
```

---

##  Summary  

✔ Arithmetic, Assignment, Comparison, and Logical operators  
✔ Conditional statements (`if`, `else if`, `else`, `switch`)  
✔ Loops (`for`, `while`, `do...while`)  
✔ Mini projects: Even/Odd, Voting, Multiplication Table  

👉 These concepts help us **move from storing values to using them logically**.  

---

✨ **Next Class Preview**:  
We’ll dive into **functions** — how to group code into reusable blocks.  

---