# JavaScript Class 3 – Functions (Deep Dive)

---

In the last class, we learned about operators, conditions, and loops.  
Now let’s make our code **reusable, powerful, and organized** using **functions**.  

---

## 🔹 1. Functions Basics

Functions = blocks of code we can **define once** and **use many times**.

```js
function greet(name) {
  return `Hello, ${name}!`;
}

console.log(greet("Dipto")); // Hello, Dipto!
console.log(greet("Student")); // Hello, Student!
```

---

## 🔹 2. Parameters & Return

```js
function add(a, b) {
  return a + b;
}

let result = add(5, 7);
console.log("Sum:", result);
```

---

## 🔹 3. Arrow Functions (ES6)

Shorter way to write functions.

```js
const square = (n) => n * n;
console.log(square(4)); // 16
```

---

## 🔹 4. Scope

- **Global Scope** → accessible everywhere  
- **Local Scope** → inside a function  
- **Block Scope** → inside `{}` (with let/const)

```js
let x = 10; // global

function test() {
  let y = 20; // local
  console.log(x + y);
}

test();  
```

---

## 🔹 5. Recursive Functions

A function that calls **itself**.

```js

function countDown(num) {
  if(num ===1){
    console.log( num)
    console.log('done')
    return
  }

  console.log(num)
  countDown(num-1)
}

countDown(10);
```

---

## 🔹 6. Callback Functions

Passing a function as an argument to another function.

```js
function calculate(a, b, callback) {
  return callback(a, b);
}

let sum = calculate(5, 3, (x, y) => x + y);
console.log("Sum:", sum);
```

---

## 🔹 Practice

✅ Write a recursive function to reverse a string  
✅ Write a function that checks if a number is prime  

---

✨ **Next Class Preview:** Arrays & their magical methods!
