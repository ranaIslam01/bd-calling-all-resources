# 💡 JavaScript — Class 5: Objects (Simplified & Practical Lesson)

## 🎯 Learning Goals
By the end of this class, you will be able to:
- Understand what an object is and why we use it  
- Create objects in different ways  
- Access, add, and remove properties  
- Use `this` inside object methods  
- Understand prototypes & classes (basic intro)  
- Copy and merge objects safely  

---

## 🧩 1️⃣ What Is an Object?

An **object** stores data in **key → value pairs**.

Keys are strings (or symbols), and values can be **anything** — numbers, strings, arrays, or functions.

```js
const student = {
  name: "Aisha",
  age: 20,
  grades: [90, 85, 78]
};
```

Here, `student` is an object with three properties: `name`, `age`, and `grades`.

---

## 🏗️ 2️⃣ Ways to Create an Object

### 🔸 1. Object Literal (most common)
```js
const person = { name: "Rafi", age: 22 };
```

### 🔸 2. Using `new Object()`
```js
const obj = new Object();
obj.x = 10;
```

### 🔸 3. Constructor Function
```js
function Person(name) {
  this.name = name;
}
const p1 = new Person("Nadia");
```

### 🔸 4. Using `class` (modern way)
```js
class Person {
  constructor(name) {
    this.name = name;
  }
  greet() {
    console.log(`Hi ${this.name}`);
  }
}
const p2 = new Person("Rana");
p2.greet();
```

---

## 🔑 3️⃣ Accessing and Changing Properties

```js
const user = { name: "Ali", age: 19 };

// Access
console.log(user.name);     // Dot notation
console.log(user["age"]);   // Bracket notation

// Add or remove
user.city = "Dhaka";        // Add property
delete user.age;            // Remove property
```

✅ Use **dot** for normal keys and **brackets** for keys with spaces or variables.

---

## ⚙️ 4️⃣ Object Methods and `this`

A **method** is a function inside an object.

```js
const counter = {
  value: 0,
  increase() {
    this.value++;
  }
};

counter.increase();
console.log(counter.value); // 1
```

- Inside methods, **`this`** refers to the object itself.  
- Arrow functions **don’t** have their own `this`, so avoid them for methods.

❌ **Don’t do this:**
```js
const bad = {
  value: 1,
  inc: () => { this.value++; } // `this` is not `bad`
};
```

---

## 🧬 5️⃣ Prototype & Inheritance (Intro)

Every object has a hidden link to another object called its **prototype**.

Class = blueprint

Constructor = “make a new object with these properties”

this = the object being made

super() = borrow parent’s setup

Example:
```js
const animal = {
  speak() { console.log("Sound..."); }
};

const dog = Object.create(animal);
dog.name = "Tommy";
dog.speak(); // "Sound..." (inherited)
```

with class : 
```js 
class Animal {
  speak() {
    console.log('speaking');
  }
}

class Dog extends Animal {
  constructor(name) {
    super(); // calls Animal’s constructor (if it had one)
    this.name = name;
  }

  speak() {
    super.speak(); // call parent’s method
    console.log(`${this.name} is barking!`);
  }
}

const dog = new Dog('Tommy');
dog.speak();
```

- `Object.create(proto)` creates a new object that inherits from another.  
- Modern JS uses **classes** for this.

---

## 🧰 6️⃣ Copying & Merging Objects

### Shallow Copy
```js
const user = { name: "A", info: { age: 20 } };
const copy = { ...user };
copy.info.age = 25;
console.log(user.info.age); // 25 (shared reference!)
```

### Deep Copy (safe)
```js
const deepCopy = JSON.parse(JSON.stringify(user));
```

> Deep copy creates a completely separate copy of nested objects.

---

## 🎯 7️⃣ Destructuring (Shortcut)

Extract values from objects easily:
```js
const person = { name: "Sara", age: 21 };
const { name, age } = person;
console.log(name); // Sara
```

You can also rename or set defaults:
```js
const { name: fullName, nick = "No Nickname" } = person;
```


## 📦 9️⃣ JSON (Convert Object ↔ String)

```js
const obj = { name: "Mina", age: 25 };
const str = JSON.stringify(obj); // object → string
const back = JSON.parse(str);    // string → object
```

Useful for saving or sending data to APIs.

---

## 🧠 10️⃣ Mini Practice

### 🟢 Easy
```js
const car = { make: "Toyota", year: 2015 };
car.age = function() {
  return new Date().getFullYear() - this.year;
};
console.log(car.age());
```

### 🟡 Medium
```js
const user = { name: "Ali", scores: [10, 20] };
const copy = { ...user };
copy.scores.push(30);
console.log(user.scores); // [10, 20, 30]
```

---

## 📝 Quick Recap Quiz

1. What is an object in JavaScript?  
2. What’s the difference between dot and bracket notation?  
3. What does `this` refer to inside a method?  
4. What’s the difference between shallow and deep copy?  
5. Why should we avoid arrow functions for object methods?


## 🏁 Summary

| Concept | Meaning |
|----------|----------|
| Object | Collection of key-value pairs |
| Method | Function inside an object |
| `this` | Refers to the current object |
| Prototype | Hidden parent object used for inheritance |
| Shallow Copy | Copies top-level only |
| Deep Copy | Copies everything (nested too) |

---

✨ **End of Class 5 — Objects**
