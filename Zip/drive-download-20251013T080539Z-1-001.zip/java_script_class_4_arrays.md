# JavaScript — Class 4

**Topic:** Arrays (Deep Dive)

---

## Quick Summary

Arrays are **ordered collections** of values (numbers, strings, objects, other arrays, etc.). They are *zero-indexed*, meaning the first item starts at index `0`.

```js
let fruits = ["apple", "banana", "mango"];
console.log(fruits[0]); // "apple"
```

---

# 🔹 1. Creating Arrays

### Different Ways to Create Arrays

```js
const a = [1, 2, 3]; // simple array
const b = new Array(3); // creates an empty array with 3 slots
const c = Array.of(1, 2, 3); // safer constructor
const d = Array.from('abc'); // ['a','b','c']
```

✅ Best practice → use square brackets `[]` for readability.

---

# 🔹 2. Access & Properties

- **Accessing values:** `arr[index]`
- **Length:** `arr.length`
- **Last element:** `arr.at(-1)` or `arr[arr.length - 1]`

```js
const numbers = [10, 20, 30];
console.log(numbers.at(-1)); // 30
```

---

# 🔹 3. Mutating vs Non-Mutating Methods

| Mutates Original | Returns New Array |
|------------------|------------------|
| push, pop, shift, unshift | map, filter, slice, concat |
| splice, sort, reverse | flat, flatMap |

**Why this matters:**  
Mutating methods change your data directly — avoid if you want to keep your original array unchanged.

---

# 🔹 4. Basic Methods

```js
let nums = [1, 2, 3];
nums.push(4);   // adds to end → [1,2,3,4]
nums.pop();     // removes last → [1,2,3]
nums.unshift(0);// adds to start → [0,1,2,3]
nums.shift();   // removes first → [1,2,3]
```

---

# 🔹 5. Iteration

```js
let students = ["A", "B", "C"];
for (let s of students) {
  console.log(s);
}

// OR
students.forEach((s, i) => console.log(i, s));
```

🟢 Use `for...of` when you want to loop cleanly.  
🟢 Use `forEach()` when you don’t need to stop or break out of the loop.

---

# 🔹 6. Higher-Order Methods

These methods use callback functions — functions you pass inside another function.

```js
let numbers = [1,2,3,4];

let doubled = numbers.map(n => n * 2); // [2,4,6,8]
let evens = numbers.filter(n => n % 2 === 0); // [2,4]
let sum = numbers.reduce((a, b) => a + b, 0); // 10

console.log(doubled, evens, sum);
```

### Breakdown:
- **map()** → transforms every element.
- **filter()** → keeps only elements that match a condition.
- **reduce()** → combines all values into one (sum, product, object, etc.).

---

# 🔹 7. Slice & Splice

```js
let arr = [1, 2, 3, 4, 5];
let part = arr.slice(1, 4); // [2,3,4] (does NOT change arr)

arr.splice(2, 1, 99); // removes 1 item at index 2, adds 99
console.log(arr); // [1,2,99,4,5]
```

🧠 Remember:
- `slice()` → copies part of the array.
- `splice()` → changes the array directly.

---

# 🔹 8. Search & Check

```js
let colors = ["red", "green", "blue"];

console.log(colors.includes("green")); // true
console.log(colors.indexOf("blue"));   // 2
```

---

# 🔹 9. Combining & Copying

```js
let a = [1, 2];
let b = [3, 4];
let combined = a.concat(b); // [1,2,3,4]

// OR
let spreadCombined = [...a, ...b]; // same result
```

🧠 **Spread Operator (`...`)** helps you copy or merge arrays easily.

---

# 🔹 10. Destructuring Arrays

```js
const fruits = ["apple", "banana", "mango"];
const [first, second] = fruits;
console.log(first); // apple
```

You can skip items:
```js
const [ , , last] = fruits;
console.log(last); // mango
```

---

# 🔹 11. Flattening Arrays

```js
let nested = [[1,2],[3,4]];
let flat = nested.flat(); // [1,2,3,4]
```

---

# 🔹 12. Practice Exercises

✅ Filter odd numbers  
✅ Create an array of squares  
✅ Find the largest number using reduce  
✅ Combine two arrays using spread  
✅ Destructure the first and last values  
✅ Flatten a nested array

**Example:**
```js
const arr = [1,2,3,4,5];
const odds = arr.filter(n => n % 2 !== 0);
const squares = arr.map(n => n * n);
const sum = arr.reduce((a, b) => a + b, 0);

console.log(odds, squares, sum);
```

---

# 🔹 13. Common Pitfalls

⚠️ `sort()` converts numbers to strings by default → use `arr.sort((a,b) => a-b)`  
⚠️ `splice()` changes your array → use `slice()` if you don’t want to mutate it  
⚠️ `forEach()` doesn’t support `break` or `return`

---

# 🔹 14. Mini Project Idea
Create a simple score tracker:

```js
let scores = [10, 20, 30, 40];
let total = scores.reduce((a, b) => a + b, 0);
let average = total / scores.length;
console.log(`Average Score: ${average}`);
```

---

# ✨ Next Class Preview
**Topic:** Objects — The power of key-value pairs!

